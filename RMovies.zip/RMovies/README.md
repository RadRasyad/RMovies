# RMovies
RMovies - BAJP sub-2

##
set api key in gradle.properties -> apiKey = "api key"
